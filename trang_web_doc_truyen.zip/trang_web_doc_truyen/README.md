# Trang web đọc truyện - Bài tập CSS

Mở `index.html` trên trình duyệt. Nhấp vào mục lục để nhảy đến nội dung chương tương ứng.

Tập tin: `index.html`, `styles.css`, `anh-bia.png`. Nội dung truyện là văn bản minh họa tự viết cho mục đích thực hành.

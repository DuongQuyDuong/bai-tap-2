# Nhật ký tương tác AI – SmartFactory

> Đây là bản tổng hợp nội dung trao đổi với AI khi chuẩn bị bài; không phải bằng chứng đã chạy benchmark hay đã đo dữ liệu thực tế.

## Prompt 1
**Câu hỏi:** Covering Index là gì và tại sao truy vấn Dashboard có thể đọc nhanh?

**Tóm tắt trả lời:** Covering Index chứa đủ các cột mà truy vấn cần nên có thể đọc từ secondary index mà không phải tra cứu bản ghi đầy đủ. Với chỉ mục `(sensor_id, recorded_at, temperature, humidity, status)`, truy vấn trong đề có thể được bao phủ.

## Prompt 2
**Câu hỏi:** InnoDB lưu Clustered Index và Secondary Index như thế nào?

**Tóm tắt trả lời:** Bảng InnoDB được tổ chức theo clustered index, thường là PRIMARY KEY, với bản ghi dữ liệu tại lá. Lá của secondary index chứa các cột được lập chỉ mục và giá trị khóa chính để truy xuất bản ghi gốc. Chỉ mục rộng thường cần nhiều trang hơn.

## Prompt 3
**Câu hỏi:** Vì sao thêm các cột DECIMAL và VARCHAR vào Index có thể tăng Write Penalty?

**Tóm tắt trả lời:** Khi INSERT, InnoDB cần cập nhật cả clustered index và secondary index. Mỗi mục secondary index lớn hơn sẽ làm tiêu tốn nhiều page, buffer pool và I/O hơn. Tuy nhiên mức ảnh hưởng thực tế phụ thuộc kích thước dữ liệu, tần suất ghi và phần cứng.

## Prompt 4
**Câu hỏi:** So sánh kích thước dữ liệu các kiểu cột theo byte ra sao?

**Tóm tắt trả lời:** `INT` thường 4 byte; `BIGINT` 8 byte; `DATETIME` không có phần giây lẻ thường 5 byte; `DECIMAL(5,2)` thường 3 byte; `VARCHAR(20)` thay đổi theo chuỗi và charset, có thêm byte độ dài. Secondary index của InnoDB còn mang khóa chính; tổng kích thước thực tế phụ thuộc overhead và cấu trúc trang.

## Prompt 5
**Câu hỏi:** Vì sao `EXPLAIN` trên bảng demo 5 dòng có thể không hiện `idx_lean_search`?

**Tóm tắt trả lời:** Optimizer dựa trên thống kê và chi phí; quét toàn bảng rất nhỏ có thể rẻ hơn đọc qua Index. Muốn đánh giá chính xác cần đủ dòng, chạy `ANALYZE TABLE` khi cần, và đo hiệu năng bằng workload thực tế.

## Kết luận tự đánh giá
Chọn Lean Index `(sensor_id, recorded_at)` cho hệ thống ghi liên tục; kiểm tra `SHOW TABLE STATUS`, `information_schema.TABLES` và `EXPLAIN` trước/sau. Không tự gán số liệu tiết kiệm hoặc tăng tốc chưa đo được.

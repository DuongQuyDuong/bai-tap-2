# Báo cáo tối ưu Index – SmartFactory

## Chẩn đoán
Bảng `SensorLogs` thu thập dữ liệu cảm biến liên tục. Chỉ mục `idx_fat_covering(sensor_id, recorded_at, temperature, humidity, status)` bao phủ truy vấn Dashboard: MySQL có thể lấy ba giá trị đo ngay từ secondary index mà không cần tra cứu thêm hàng dữ liệu theo khóa chính. Đây là lợi ích đọc, nhưng chỉ mục chứa nhiều cột làm bản ghi B-Tree lớn, giảm số mục vừa trong mỗi trang, tăng nhu cầu đĩa và bộ nhớ đệm. Mỗi lần INSERT, InnoDB phải ghi bản ghi dữ liệu và duy trì chỉ mục phụ; chỉ mục càng rộng thì chi phí ghi và áp lực I/O có thể càng cao.

## Giải pháp và đánh đổi
Xóa `idx_fat_covering`, thay bằng `idx_lean_search(sensor_id, recorded_at)`. Hai cột đầu đủ hỗ trợ lọc theo cảm biến và khoảng thời gian. Khi SELECT cần `temperature`, `humidity`, `status`, MySQL có thể phải tra cứu thêm bảng gốc, nên có khả năng chậm hơn. Đổi lại, chỉ mục gọn hơn, giảm lượng dữ liệu cần bảo trì trong luồng ghi dày đặc. Không thể khẳng định INSERT tăng năm lần hoặc dung lượng giảm 70% nếu chưa đo.

## Kết quả thực nghiệm cần ghi
| Chỉ tiêu | Trước | Sau |
|---|---|---|
| `INDEX_LENGTH` (byte) | Chưa đo | Chưa đo |
| `DATA_LENGTH` (byte) | Chưa đo | Chưa đo |
| `EXPLAIN.key` | Cần kiểm tra | Cần kiểm tra |
| `EXPLAIN.Extra` | Cần kiểm tra | Cần kiểm tra |

Script có 5 dòng demo để kiểm tra chức năng, nên `EXPLAIN` có thể chọn quét bảng và `INDEX_LENGTH` chưa cho thấy mức chênh lệch rõ ràng. Cần chạy trên bộ dữ liệu đủ lớn, ghi số đo thực tế mới có thể kết luận tiết kiệm tài nguyên.

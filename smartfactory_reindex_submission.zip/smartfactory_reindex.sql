-- SMARTFACTORY: Fat Covering Index vs Lean Index
-- MySQL 8.0 | Chay trong database thuc hanh rieng.
-- Canh bao: SCRIPT TAO LAI bang SensorLogs; khong dung tren du lieu can giu.

CREATE DATABASE IF NOT EXISTS smartfactory_db;
USE smartfactory_db;
DROP TABLE IF EXISTS SensorLogs;

CREATE TABLE SensorLogs (
    log_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sensor_id INT NOT NULL,
    recorded_at DATETIME NOT NULL,
    temperature DECIMAL(5,2),
    humidity DECIMAL(5,2),
    status VARCHAR(20)
) ENGINE=InnoDB;

-- Du lieu demo: nho, de kiem tra logic; khong dung de suy ra toc do / tiet kiem GB.
INSERT INTO SensorLogs (sensor_id, recorded_at, temperature, humidity, status) VALUES
(105, '2026-06-20 08:00:00', 28.50, 67.20, 'NORMAL'),
(105, '2026-06-20 09:00:00', 35.10, 60.00, 'WARNING'),
(105, '2026-06-21 10:00:00', 42.90, 48.50, 'CRITICAL'),
(106, '2026-06-20 09:30:00', 26.30, 70.10, 'NORMAL'),
(107, '2026-06-22 07:30:00', 29.90, 64.00, 'NORMAL');

-- 1. Mo phong he thong truoc toi uu
CREATE INDEX idx_fat_covering
ON SensorLogs(sensor_id, recorded_at, temperature, humidity, status);

-- Doi chieu EXPLAIN va Storage TRUOC khi thay doi
SHOW INDEX FROM SensorLogs;
SHOW TABLE STATUS LIKE 'SensorLogs';
SELECT TABLE_NAME, TABLE_ROWS,
       DATA_LENGTH AS data_bytes, INDEX_LENGTH AS index_bytes,
       ROUND(DATA_LENGTH / 1024 / 1024, 4) AS data_mb,
       ROUND(INDEX_LENGTH / 1024 / 1024, 4) AS index_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'smartfactory_db' AND TABLE_NAME = 'SensorLogs';
EXPLAIN SELECT temperature, humidity, status
FROM SensorLogs
WHERE sensor_id = 105 AND recorded_at >= '2026-06-20';

-- 2. Chuyen tu Fat sang Lean: giu cot loc va sap xep
ALTER TABLE SensorLogs DROP INDEX idx_fat_covering;
CREATE INDEX idx_lean_search ON SensorLogs(sensor_id, recorded_at);

-- 3. Doi chieu EXPLAIN va Storage SAU khi thay doi
SHOW INDEX FROM SensorLogs;
SHOW TABLE STATUS LIKE 'SensorLogs';
SELECT TABLE_NAME, TABLE_ROWS,
       DATA_LENGTH AS data_bytes, INDEX_LENGTH AS index_bytes,
       ROUND(DATA_LENGTH / 1024 / 1024, 4) AS data_mb,
       ROUND(INDEX_LENGTH / 1024 / 1024, 4) AS index_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'smartfactory_db' AND TABLE_NAME = 'SensorLogs';
EXPLAIN SELECT temperature, humidity, status
FROM SensorLogs
WHERE sensor_id = 105 AND recorded_at >= '2026-06-20';

-- Luu y: tren tap du lieu demo rat nho, Optimizer co the chon full table scan,
-- cot key co the NULL; Index_length co the khong giam do cap phat theo page.
-- Muon chung minh hieu nang, can du lieu lon va benchmark co kiem soat.

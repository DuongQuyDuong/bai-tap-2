# Bài thực hành CSS - Menu ngang Dropdown

- Mở `index.html` bằng trình duyệt.
- Rê chuột vào `Sem 1` hoặc `Sem 2` để xem menu con thả xuống.
- Màu nền đen, chữ trắng, hover đỏ. CSS được tách riêng trong `styles.css`.

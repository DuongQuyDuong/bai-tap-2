# Nhật ký làm việc với AI – QuickFeed

> Ghi chú trung thực: Phần **trao đổi đã thực hiện** tóm tắt yêu cầu/hỗ trợ trong cuộc hội thoại; phần **prompt tự học đề xuất** bên dưới là câu hỏi để tiếp tục luyện tập, không được trình bày như đã hỏi trong quá khứ.

## 1. Trao đổi đã thực hiện

**Yêu cầu:** “Chỉ tôi cách làm” bài tối ưu Index QuickFeed.

**Nội dung AI hỗ trợ:** Hướng dẫn tạo bảng `Posts`, tạo và kiểm tra năm index, dùng `SHOW TABLE STATUS` và `information_schema.TABLES` để đo `DATA_LENGTH`, `INDEX_LENGTH`, phân biệt index cần giữ và index cần loại bỏ.

**Yêu cầu:** Gửi script SQL đang viết, yêu cầu “sửa lại”.

**Nội dung AI hỗ trợ:** Thay chỗ giữ tên `ten_index` bằng ba tên index cụ thể trong ví dụ; sắp xếp phần kiểm tra trước/sau tối ưu.

**Kết quả kiểm chứng bằng MySQL Workbench:** Ba `DROP INDEX` thành công; `SHOW INDEX FROM Posts` trả về ba hàng; bảng có 0 dòng, Data = 0,02 MB và Index = 0,00 MB ở số liệu sau tối ưu.

## 2. Kiến thức rút ra

- **Cardinality**: số lượng giá trị phân biệt của cột/index (trong thống kê MySQL, thường là giá trị ước tính). Index chỉ có 2–3 giá trị không luôn vô dụng; nếu truy vấn lọc nhóm nhỏ hoặc dùng index ghép, nó vẫn có thể hữu ích.
- **InnoDB Data Pages và Index Pages**: dữ liệu bảng trong InnoDB thường tổ chức theo clustered index của khóa chính; secondary index lưu các khóa đã sắp xếp cùng giá trị khóa chính để định vị hàng. Nhiều secondary index chiếm thêm trang lưu trữ, buffer pool và tăng chi phí ghi.
- **Trade-off**: bớt index giảm chi phí bảo trì khi ghi nhưng có thể khiến một vài truy vấn đọc phải quét nhiều dữ liệu hơn.
- **Bộ tối ưu hóa**: khi điều kiện `is_visible = 1` khớp gần toàn bộ bảng, full table scan có thể rẻ hơn truy vấn qua index rồi phải đọc nhiều hàng dữ liệu.
- **Đo lường**: `information_schema.TABLES.DATA_LENGTH` và `INDEX_LENGTH` là thống kê dung lượng, có thể làm tròn/ước tính và không thể dùng bảng rỗng để chứng minh mức tiết kiệm của dữ liệu sản xuất.

## 3. Prompt tự học đề xuất (chưa xác nhận đã thực hiện)

1. “Tại sao secondary index của InnoDB cần thêm khóa chính và điều đó ảnh hưởng gì đến dung lượng?”
2. “Cho ví dụ dùng EXPLAIN để so sánh full table scan với idx_is_visible khi 99% bài viết có is_visible = 1.”
3. “Khác biệt giữa Index Length và Data Length trong information_schema.TABLES là gì?”
4. “Bảng archive hầu như chỉ đọc có thể chấp nhận nhiều index hơn bảng ghi liên tục không? Vì sao?”
5. “Khi tìm kiếm từ khóa trong cột TEXT, FULLTEXT index có ưu và nhược điểm nào so với B-Tree index tiền tố?”

## 4. Tự đánh giá

Sau tối ưu, `idx_user_id` và `idx_created_at` vẫn được giữ; ba secondary index theo yêu cầu đã bị loại bỏ. Để bảo vệ bằng số liệu thực tế tốt hơn cần thử nghiệm với tập dữ liệu đủ lớn và lưu số liệu trước/sau cùng thời gian đo `INSERT`.

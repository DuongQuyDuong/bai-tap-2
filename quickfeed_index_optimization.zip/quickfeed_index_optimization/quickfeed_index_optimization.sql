-- QUICKFEED: INDEX OPTIMIZATION LAB
-- Canh bao: Script tai hien bai thuc hanh tu dau; DROP TABLE Posts se xoa du lieu cu.
-- Chi chay tren quickfeed_db thu nghiem, KHONG chay tren CSDL san xuat.
-- Khi ban da hoan thanh toi uu truoc do, khong can chay lai script nay de nop bai.

CREATE DATABASE IF NOT EXISTS quickfeed_db;
USE quickfeed_db;

-- 1. Tao lai bang va 5 secondary index ban dau (chi cho moi truong demo)
DROP TABLE IF EXISTS Posts;
CREATE TABLE Posts (
    post_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    content TEXT,
    post_type VARCHAR(10),
    is_visible BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE INDEX idx_user_id ON Posts(user_id);
CREATE INDEX idx_content ON Posts(content(255));
CREATE INDEX idx_post_type ON Posts(post_type);
CREATE INDEX idx_is_visible ON Posts(is_visible);
CREATE INDEX idx_created_at ON Posts(created_at);

-- 2. Luu log truoc/sau de de doi chieu, ke ca khi chay het script
DROP TABLE IF EXISTS quickfeed_storage_audit;
CREATE TABLE quickfeed_storage_audit (
    phase VARCHAR(12) PRIMARY KEY,
    row_count BIGINT,
    data_bytes BIGINT,
    index_bytes BIGINT,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Neu can minh hoa dung luong tren dataset co du lieu, hay INSERT du lieu mau
-- vao Posts TRUOC khoi 'BEFORE' ben duoi.

-- 3. Quan sat TRUOC toi uu
SHOW INDEX FROM Posts;
SHOW TABLE STATUS LIKE 'Posts';

SELECT TABLE_NAME, TABLE_ROWS,
       ROUND(DATA_LENGTH / 1024 / 1024, 2) AS Data_MB,
       ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS Index_MB
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db' AND TABLE_NAME = 'Posts';

INSERT INTO quickfeed_storage_audit (phase, row_count, data_bytes, index_bytes)
SELECT 'BEFORE', TABLE_ROWS, DATA_LENGTH, INDEX_LENGTH
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db' AND TABLE_NAME = 'Posts';

-- 4. Chi loai bo 3 secondary index kem gia tri theo yeu cau bai
ALTER TABLE Posts DROP INDEX idx_content;
ALTER TABLE Posts DROP INDEX idx_post_type;
ALTER TABLE Posts DROP INDEX idx_is_visible;

-- Giu nguyen PRIMARY, idx_user_id va idx_created_at

-- 5. Quan sat SAU toi uu
SHOW INDEX FROM Posts;
SHOW TABLE STATUS LIKE 'Posts';

SELECT TABLE_NAME, TABLE_ROWS,
       ROUND(DATA_LENGTH / 1024 / 1024, 2) AS Data_MB,
       ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS Index_MB
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db' AND TABLE_NAME = 'Posts';

INSERT INTO quickfeed_storage_audit (phase, row_count, data_bytes, index_bytes)
SELECT 'AFTER', TABLE_ROWS, DATA_LENGTH, INDEX_LENGTH
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db' AND TABLE_NAME = 'Posts';

-- 6. Bang doi chieu (so lieu co the bang nhau voi bang trong)
SELECT phase, row_count,
       ROUND(data_bytes / 1024 / 1024, 2) AS Data_MB,
       ROUND(index_bytes / 1024 / 1024, 2) AS Index_MB,
       recorded_at
FROM quickfeed_storage_audit
ORDER BY FIELD(phase, 'BEFORE', 'AFTER');

-- So luong secondary index can bao tri khi INSERT: 5 -> 2 (giam 3).
-- PRIMARY KEY van can duoc cap nhat. Day la giam cong viec logic,
-- khong phai bang chung thoi gian INSERT giam 3 lan.

# Báo cáo tối ưu Index – QuickFeed

## 1. Chẩn đoán và quyết định

Bảng `Posts` ban đầu có năm *secondary index*, chưa kể khóa chính `PRIMARY`. Mỗi lệnh `INSERT` không chỉ ghi bản ghi vào clustered index của InnoDB mà còn phải bổ sung mục tương ứng vào từng secondary B-Tree. Điều này tăng công việc ghi, dung lượng lưu trữ và áp lực lên buffer pool. `idx_content` đánh chỉ mục tiền tố 255 ký tự của văn bản nên có thể lớn và không phù hợp với tìm kiếm từ khóa toàn văn. `idx_post_type` chỉ có ba loại và `idx_is_visible` chỉ có hai trạng thái, vì thế thường kém hữu ích đối với truy vấn chọn phần lớn bản ghi. Tuy nhiên, hiệu quả thực tế vẫn phụ thuộc phân bố dữ liệu và điều kiện truy vấn.

| Index | Quyết định | Lý do |
|---|---|---|
| `idx_user_id` | Giữ | Lọc bài viết theo người dùng |
| `idx_content` | Xóa | Chi phí lưu trữ lớn, không thay thế FULLTEXT |
| `idx_post_type` | Xóa | Cardinality thấp trong kịch bản đề bài |
| `idx_is_visible` | Xóa | Hai giá trị, thường chọn quá nhiều dòng |
| `idx_created_at` | Giữ | Hỗ trợ truy vấn theo thời gian |

## 2. Đo đạc thực tế

| Trạng thái | Số dòng | Data (MB) | Index (MB) | Số secondary index |
|---|---:|---:|---:|---:|
| Trước tối ưu | Chưa ghi nhận | Chưa ghi nhận | Chưa ghi nhận | 5 |
| Sau tối ưu (ảnh MySQL Workbench) | 0 | 0,02 | 0,00 | 2 |

Ảnh thực hành xác nhận ba lệnh `DROP INDEX` thành công và `SHOW INDEX` còn ba hàng, gồm `PRIMARY` và hai secondary index. Do bảng đang rỗng, `Index_MB` làm tròn hai chữ số có thể là `0,00`; **chưa thể kết luận đã giải phóng được bao nhiêu MB**. Muốn chứng minh chênh lệch dung lượng, cần nạp lượng dữ liệu đại diện, đo *trước khi xóa*, sau đó đo lại cùng điều kiện.

## 3. Đánh đổi Read/Write

Nhiều index có thể giúp một số lệnh `SELECT` nhưng khiến `INSERT`, `UPDATE`, `DELETE` phải duy trì nhiều cấu trúc hơn. Loại ba index làm giảm từ năm xuống hai lần bảo trì *secondary index* cho mỗi bản ghi chèn, **không đồng nghĩa** tốc độ ghi tăng ba lần. Với tìm kiếm nội dung, có thể cân nhắc `FULLTEXT` và `MATCH ... AGAINST` dựa trên nhu cầu thực tế.

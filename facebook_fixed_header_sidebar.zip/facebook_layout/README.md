# Bài thực hành: Fixed Header và Sidebar

Trang web mô phỏng bố cục Facebook bằng HTML5 và CSS thuần.

- Header cố định trên cùng (`position: fixed`)
- Sidebar trái (menu), sidebar phải (người liên hệ)
- Nội dung chính gồm tin, ô đăng bài và bài viết mẫu
- Sidebar cố định theo vùng nhìn (`position: sticky`)
- Responsive: ẩn bớt sidebar trên màn hình nhỏ

## Cách chạy
Mở `index.html` bằng trình duyệt; `styles.css` phải cùng thư mục.

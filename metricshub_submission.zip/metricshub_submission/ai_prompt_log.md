# Nhật ký tương tác AI — MetricsHub

> Tài liệu tổng hợp nội dung tìm hiểu cùng trợ lý AI trong quá trình chuẩn bị bài; không phải nhật ký nguyên văn các lần kiểm thử trình duyệt.

## 1. CSS Grid hay Flexbox cho Bento Box?
**Câu hỏi nghiên cứu:** Khi widget cần chiếm 2 hàng và 2 cột, nên dùng công cụ gì?

**Kiến thức rút ra:** Grid xử lý hai trục hàng/cột, hỗ trợ `grid-column` và `grid-row` với `span`; Flexbox chủ yếu sắp xếp theo một trục và không có cơ chế span hàng/cột trực tiếp.

## 2. Navbar có tên menu dài
**Câu hỏi nghiên cứu:** Làm sao tránh tràn chữ khi menu đổi sang ngôn ngữ có từ dài?

**Kiến thức rút ra:** Dùng Flexbox kết hợp `flex-wrap: wrap`, `min-width: 0`, và `overflow-wrap: anywhere` cho văn bản dài; tránh chiều rộng cột cố định.

## 3. Bootstrap 12 cột
**Câu hỏi nghiên cứu:** `col-sm-4` khác `col-md-4` ở điểm nào?

**Kiến thức rút ra:** `sm` áp dụng từ breakpoint 576px, `md` từ 768px trong Bootstrap 5; `col-12 col-md-4` là toàn chiều rộng ở màn nhỏ và 4/12 chiều rộng mỗi ô từ 768px trở lên.

## 4. Khoảng cách với gap
**Câu hỏi nghiên cứu:** `gap` giúp gì so với `margin` trong Grid và Flexbox?

**Kiến thức rút ra:** `gap` thiết lập khoảng cách giữa các ô/con trực tiếp mà không thêm khoảng cách ra phía ngoài container; mã CSS gọn, dễ bảo trì hơn.

## 5. Kiểm thử cần thực hiện
- Desktop: ba cột dashboard và ba gói giá; widget lớn span 2×2.
- Tablet: dashboard hai cột, không chồng lấn.
- Mobile ~375px: dashboard một cột, Navbar xuống dòng, pricing xếp dọc.

**Trạng thái:** Các quy tắc responsive đã được triển khai trong mã nguồn; chưa có đo đạc/ảnh kiểm thử thực tế trên trình duyệt trong phiên này.

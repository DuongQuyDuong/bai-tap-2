# Chiến lược bố cục MetricsHub

**Đánh giá legacy:** Navbar dùng Grid cột cố định dễ tràn chữ khi đổi ngôn ngữ. Dashboard dùng nhiều Flexbox lồng nhau khiến khó kiểm soát widget chiếm nhiều hàng/cột. Pricing dùng float và media query thủ công dù Bootstrap đã hỗ trợ sẵn.

**Giải pháp:** Navbar dùng **Flexbox** (`justify-content: space-between`, `align-items: center`, `flex-wrap: wrap`) để các mục tự co giãn và xuống dòng theo nội dung. Dashboard dùng **CSS Grid** với ba cột, `grid-column: span 2` và `grid-row: span 2` cho Bento Box, loại bỏ lớp `.column` dư thừa. Pricing dùng **Bootstrap** (`row`, `col-12 col-md-4`) để hiển thị ba cột ở desktop và xếp dọc ở mobile.

**Đánh đổi:** Grid phù hợp bố trí 2D; Flexbox hiệu quả để sắp xếp thành phần theo một chiều. Chúng có thể phối hợp: widget đặt trong Grid vẫn có thể dùng Flexbox để căn nội dung bên trong. `gap` giúp giữ khoảng cách nhất quán thay cho nhiều margin riêng lẻ.

# Bài thực hành CSS Box Model

Mở `index.html` bằng trình duyệt để xem kết quả.

- `.boxmodel`: khung có viền 4 màu, width, padding và margin căn giữa.
- `.boxmodel p`: viền chấm màu đỏ sẫm và padding 10px.
- `#boxmodel1`, `#boxmodel2`, `#boxmodel3`: khoảng cách phía dưới lần lượt 20px, 40px, 60px.

# Bài tập CSS - Menu dọc Dropdown

- `index.html`: Menu ACCP i10 gồm Sem 1, Sem 2, Sem 3, Sem 4.
- `styles.css`: Định dạng menu dọc nền đen, liên kết chữ trắng, hover đỏ; Sem 1 và Sem 2 mở danh sách con ở bên phải.

## Cách chạy
Mở file `index.html` bằng trình duyệt, đưa chuột vào Sem 1 hoặc Sem 2 để xem menu con.

# Thực hành nhúng CSS vào trang web

- `inline.html`: CSS trực tiếp trong thuộc tính `style` của thẻ HTML.
- `internal.html`: CSS trong thẻ `<style>` bên trong `<head>`.
- `external.html`: CSS từ tệp `style.css` thông qua thẻ `<link>`.

Mở từng file HTML bằng trình duyệt để xem kết quả. Giữ `external.html` và `style.css` trong cùng thư mục.

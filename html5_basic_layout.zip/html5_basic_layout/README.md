# Bài thực hành bố cục HTML5

Trang web sử dụng các thẻ ngữ nghĩa `header`, `nav`, `section`, `article`, `aside`, `footer` và file CSS bên ngoài.

## Cách chạy
Mở file `index.html` bằng trình duyệt. Giữ `styles.css` cùng thư mục để giao diện hiển thị đúng.
